<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\NotificationServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,
];
