<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reserva;
use App\Models\Habitacion;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;

class ReservaApiController extends Controller
{
  public function calendario()
  {
    $reservas = Reserva::with(['habitacion', 'cliente'])
      ->whereIn('estado', [
        'Check-in',
        'Pendiente',
        'Pendiente de Confirmación',
        'Reservada-Pendiente',
        'Reservada-Confirmada'
      ])
      ->get()
      ->map(function ($reserva) {
        $color = match ($reserva->estado) {
          'Check-in' => '#dc3545', // rojo
          'Pendiente' => '#ffc107', // amarillo
          'Pendiente de Confirmación' => '#007bff', // azul
          'Reservada-Pendiente' => '#17a2b8', // celeste
          'Reservada-Confirmada' => '#6610f2', // morado
          default => '#6c757d'
        };
        $title = 'Hab. ' . $reserva->habitacion->numero . ' - ' . $reserva->estado;
        return [
          'id' => $reserva->id,
          'title' => $title,
          'start' => $reserva->fecha_entrada->format('Y-m-d\TH:i:s'),
          'end' => $reserva->fecha_salida->format('Y-m-d\TH:i:s'),
          'backgroundColor' => $color,
          'borderColor' => $color,
          'extendedProps' => [
            'estado' => $reserva->estado,
            'habitacion_id' => $reserva->habitacion_id,
            'cliente_id' => $reserva->cliente_id,
            'habitacion_numero' => $reserva->habitacion->numero,
            'cliente_nombre' => $reserva->cliente->nombre,
            'precio' => $reserva->habitacion->precio,
            'adelanto' => $reserva->adelanto,
            'total' => $reserva->total
          ]
        ];
      });

    return response()->json($reservas);
  }

  public function disponibilidad(Request $request)
  {
    $request->validate([
      'fecha_entrada' => 'required|date',
      'fecha_salida' => 'required|date|after_or_equal:fecha_entrada', // Changed from 'after' to 'after_or_equal' to allow same-day stays
      'categoria_id' => 'nullable|exists:categorias,id'
    ]);

    $fechaEntrada = Carbon::parse($request->fecha_entrada);
    $fechaSalida = Carbon::parse($request->fecha_salida);

    // Obtener habitaciones disponibles
    $habitacionesDisponibles = \App\Models\Habitacion::where('estado', 'Disponible')
      ->when($request->categoria_id, function ($query) use ($request) {
        return $query->where('categoria_id', $request->categoria_id);
      })
      ->whereDoesntHave('reservas', function ($query) use ($fechaEntrada, $fechaSalida) {
        $query->where(function ($q) use ($fechaEntrada, $fechaSalida) {
          // Use proper interval overlap logic: (start1 < end2) AND (start2 < end1)
          $q->where('fecha_entrada', '<', $fechaSalida)
            ->where('fecha_salida', '>', $fechaEntrada);
        })
          ->whereIn('estado', ['Check-in', 'Pendiente']);
      })
      ->with(['categoria', 'nivel', 'imagenPrincipal'])
      ->get()
      ->map(function ($habitacion) {
        return [
          'id' => $habitacion->id,
          'numero' => $habitacion->numero,
          'categoria' => $habitacion->categoria->nombre,
          'nivel' => $habitacion->nivel->nombre,
          'precio' => $habitacion->precio,
          'descripcion' => $habitacion->descripcion,
          'caracteristicas' => $habitacion->caracteristicas,
          'imagen' => $habitacion->imagenPrincipal ? Storage::url($habitacion->imagenPrincipal->ruta) : null
        ];
      });

    return response()->json([
      'disponibles' => $habitacionesDisponibles,
      'total' => $habitacionesDisponibles->count()
    ]);
  }

  public function crearReserva(Request $request)
  {
    $request->validate([
      'habitacion_id' => 'required|exists:habitacions,id',
      'cliente_id' => 'required|exists:clientes,id',
      'fecha_entrada' => 'required|date',
      'fecha_salida' => 'required|date|after_or_equal:fecha_entrada', // Changed from 'after' to 'after_or_equal' to allow same-day stays
      'adelanto' => 'nullable|numeric|min:0'
    ]);

    // Verificar disponibilidad
    $fechaEntrada = Carbon::parse($request->fecha_entrada);
    $fechaSalida = Carbon::parse($request->fecha_salida);

    $habitacion = \App\Models\Habitacion::findOrFail($request->habitacion_id);

    if ($habitacion->estado !== 'Disponible') {
      return response()->json([
        'error' => 'La habitación no está disponible'
      ], 400);
    }

    $reservaExistente = $habitacion->reservas()
      ->where(function ($query) use ($fechaEntrada, $fechaSalida) {
        // Use proper interval overlap logic: (start1 < end2) AND (start2 < end1)
        $query->where('fecha_entrada', '<', $fechaSalida)
              ->where('fecha_salida', '>', $fechaEntrada);
      })
      ->whereIn('estado', ['Pendiente de Confirmación', 'Pendiente', 'Check-in'])
      ->exists();

    if ($reservaExistente) {
      return response()->json([
        'error' => 'La habitación ya está reservada para esas fechas'
      ], 400);
    }

    // Crear la reserva
    $reserva = Reserva::create([
      'habitacion_id' => $request->habitacion_id,
      'cliente_id' => $request->cliente_id,
      'fecha_entrada' => $fechaEntrada,
      'fecha_salida' => $fechaSalida,
      'estado' => 'Pendiente de Confirmación',
      'adelanto' => $request->adelanto ?? 0
    ]);

    // Establecer la fecha de expiración
    $reserva->setExpirationTime();

    // Actualizar el estado de la habitación a Reservada-Pendiente
    $habitacion->estado = 'Reservada-Pendiente';
    $habitacion->save();

    // Notificar a los recepcionistas sobre la nueva reserva pendiente de confirmación
    $recepcionistas = \App\Models\User::role('Recepcionista')->active()->get();
    foreach ($recepcionistas as $recepcionista) {
        $recepcionista->notify(new \App\Notifications\ReservaPendienteNotification($reserva));
    }

    return response()->json([
      'message' => 'Reserva creada exitosamente. Pendiente de confirmación por el recepcionista.',
      'reserva' => $reserva
    ], 201);
  }
}
