@extends('adminlte::page')

@section('title', 'Bienvenido')

@section('content_header')
    <h1>Bienvenido al Sistema de Gestión Hotelera</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <p>Seleccione una opción del menú para comenzar.</p>
        </div>
    </div>
@stop
